@extends('policeoffice.index')

@section('policelist')

<div id="insert-menu">
{{$formOpen}}
	<div class="col-md-3 col-lg-3">
		<div class="col-md-6 col-lg-6">{{ $polresnameLabel }} </div><div class="col-md-6 col-lg-6">{{ $polresnameInput }}</div>
	</div>
	<div class="col-md-3 col-lg-3">
		<div class="col-md-6 col-lg-6"> {{ $nameLabel }}</div><div class="col-md-6 col-lg-6">{{ $polseknameInput }}</div>
	</div>
	<div class="col-md-3 col-lg-3">
		<div class="col-md-6 col-lg-6"> {{ $longlatLabel }}</div> <div class="col-md-6 col-lg-6">{{ $longlatInput }}</div>
	</div>
	<div class="col-md-3 col-lg-3">
		<input type="submit" value="{{Lang::get('global.save')}}" id='submit-btn' />
	</div>
	
	<!-- <div class="col-md-3 col-lg-3">
		<div>{{ $phoneLabel}} {{ $phoneInput }}</div>
	</div> -->	
{{$formClose}}
</div>
<div id='polreslist'></div>
<script type="text/javascript">
	$(document).ready(function () {
		// set Theme for sub menu
		$("#insert-menu").jqxMenu({
			theme: 'metro'
		});
		 
		 $("#polsekName").jqxInput({ height: 27, width: 150, minLength: 1, theme: 'metro' });
		 $('#polsekLonglat').jqxInput({ height: 27, width: 250, minLength: 1, theme: 'metro' });
		 $("#submit-btn").jqxButton({ width: '80', height: '25'});

		 // Auto Complete Polda
		 var urlpolres = "{{url('admin/kantor/polres/autopolres')}}";
		 var sourcepolres = {
		 				dataType: 'json',
					     datafields: [
						     { name: 'id', type: 'number'}, 
						     { name: 'name', type: 'string'}
					     ],
					     url: urlpolres
					 };
		 var dataAdapterPolres = new $.jqx.dataAdapter(sourcepolres);
		 // Create a jqxInput
		 $("#polresName").jqxInput({
		     source: dataAdapterPolres,
		     displayMember: "name",
		     valueMember: "id",
		     width: 150,
		     height: 27,
		     theme: 'metro'
		 });

		 // Data Table
		var url = "{{url('admin/kantor/polsek/data')}}";
		 var source = {
			dataType: 'json',
			dataFields: [
				{ name: 'name', type: 'string' },
				{ name: 'longlat', type: 'string' }
			],
			id: 'id',
			url: url
		};
		var dataAdapter = new $.jqx.dataAdapter(source);
		$("#polreslist").jqxDataTable(
		{
		    theme: 'metro',
            width: '100%',
            pageable: true,
            pagerButtonsCount: 10,
            source: dataAdapter,
            columnsResize: true,
		    columns: [
		        { text: "{{ Lang::get('polres.polresname')}}", dataField: 'name', width: '20%' },
		        { text: "{{ Lang::get('polres.longlat')}}", dataField: 'longlat', width: 'auto' }
		    ]
		}); 

	});
</script>
@stop