@extends('policeoffice.index')

@section('policelist')
<div id="insert-menu">
{{$formOpen}}
	<div class="col-md-3 col-lg-3">
		<div class="col-md-6 col-lg-6"> {{ $nameLabel }}</div><div class="col-md-6 col-lg-6">{{ $poldanameInput }}</div>
	</div>
	<div class="col-md-3 col-lg-3">
		<div class="col-md-6 col-lg-6"> {{ $longlatLabel }}</div> <div class="col-md-6 col-lg-6">{{ $longlatInput }}</div>
	</div>
	<div class="col-md-3 col-lg-3">
		<input type="submit" value="{{Lang::get('global.save')}}" id='submit-btn' />
	</div>
	<!-- <div class="col-md-3 col-lg-3">
		<div>{{ $addressLabel }} {{ $addressInput }}</div>
	</div>
	<div class="col-md-3 col-lg-3">
		<div>{{ $phoneLabel}} {{ $phoneInput }}</div>
	</div> -->	
{{$formClose}}
</div>
<div id='poldalist'></div>

<script type="text/javascript">
	$(document).ready(function () {
		// set Theme for sub menu
		$("#insert-menu").jqxMenu({
			theme: 'metro'
		});
		 $("#poldaName").jqxInput({ height: 27, width: 150, minLength: 1, theme: 'metro' });
		 $('#poldaLonglat').jqxInput({ height: 27, width: 250, minLength: 1, theme: 'metro' });
		 $("#submit-btn").jqxButton({ width: '80', height: '25'});

		 var url = "{{url('admin/kantor/polda/data')}}";
		 var source = {
			dataType: 'json',
			dataFields: [
				{ name: 'name', type: 'string' },
				{ name: 'longlat', type: 'string' }
			],
			id: 'id',
			url: url
		};
		var dataAdapter = new $.jqx.dataAdapter(source);
		$("#poldalist").jqxDataTable(
		{
		    theme: 'metro',
            width: '100%',
            pageable: true,
            pagerButtonsCount: 10,
            source: dataAdapter,
            columnsResize: true,
		    columns: [
		        { text: "{{ Lang::get('polda.poldaname')}}", dataField: 'name', width: '20%' },
		        { text: "{{ Lang::get('polda.longlat')}}", dataField: 'longlat', width: 'auto' }
		    ]
		}); 
	});
</script>
@stop