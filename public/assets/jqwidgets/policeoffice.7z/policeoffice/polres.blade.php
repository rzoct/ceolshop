@extends('policeoffice.index')

@section('policelist')

<div id="insert-menu">
{{$formOpen}}
	<div class="col-md-3 col-lg-3">
		<div class="col-md-6 col-lg-6">{{ $poldanameLabel }} {{$poldanameHidden}}</div><div class="col-md-6 col-lg-6">{{ $poldanameInput }}</div>
	</div>
	<div class="col-md-3 col-lg-3">
		<div class="col-md-6 col-lg-6"> {{ $nameLabel }}</div><div class="col-md-6 col-lg-6">{{ $polresnameInput }}</div>
	</div>
	<div class="col-md-3 col-lg-3">
		<div class="col-md-6 col-lg-6"> {{ $longlatLabel }}</div> <div class="col-md-6 col-lg-6">{{ $longlatInput }}</div>
	</div>
	<div class="col-md-3 col-lg-3">
		<input type="submit" value="{{Lang::get('global.save')}}" id='submit-btn' />
	</div>
	
	<!-- <div class="col-md-3 col-lg-3">
		<div>{{ $phoneLabel}} {{ $phoneInput }}</div>
	</div> -->	
{{$formClose}}
</div>
<div id='polreslist'></div>
<script type="text/javascript">
	$(document).ready(function () {
		// set Theme for sub menu
		$("#insert-menu").jqxMenu({
			theme: 'metro'
		});
		 // $("#poldaName").jqxInput({ height: 27, width: 150, minLength: 1, theme: 'metro' });
		 $("#polresName").jqxInput({ height: 27, width: 150, minLength: 1, theme: 'metro' });
		 $('#polresLonglat').jqxInput({ height: 27, width: 250, minLength: 1, theme: 'metro' });
		 $("#submit-btn").jqxButton({ width: '80', height: '25'});
		 // Auto Complete Polda
		 var urlpolda = "{{url('admin/kantor/polda/autopolda')}}";
		 var sourcepolda = {
		 				dataType: 'json',
					     datafields: [
						     { name: 'id', type: 'number'}, 
						     { name: 'name', type: 'string'}
					     ],
					     url: urlpolda
					 };
		 var dataAdapterPolda = new $.jqx.dataAdapter(sourcepolda);
		 // Create a jqxInput
		 $("#poldaName").jqxInput({
		     source: dataAdapterPolda,
		     displayMember: "name",
		     valueMember: "id",
		     width: 150,
		     height: 27,
		     theme: 'metro'
		 });

		 $("#poldaName").on('select', function (event) {
		     if (event.args) {
		        var item = event.args.item;
		        $("#parentId").val(item.value);
		     }
		});

		 // Data Table
		var url = "{{url('admin/kantor/polres/data')}}";
		 var source = {
			dataType: 'json',
			dataFields: [
				{ name: 'name', type: 'string' },
				{ name: 'longlat', type: 'string' }
			],
			id: 'id',
			url: url
		};
		var dataAdapter = new $.jqx.dataAdapter(source);
		$("#polreslist").jqxDataTable(
		{
		    theme: 'metro',
            width: '100%',
            pageable: true,
            pagerButtonsCount: 10,
            source: dataAdapter,
            columnsResize: true,
		    columns: [
		        { text: "{{ Lang::get('polres.polresname')}}", dataField: 'name', width: '20%' },
		        { text: "{{ Lang::get('polres.longlat')}}", dataField: 'longlat', width: 'auto' }
		    ]
		});

	});
</script>
@stop