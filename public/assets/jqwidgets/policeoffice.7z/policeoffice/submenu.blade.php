<div id="sub-menu">
	<ul>
		<li><a href="{{url('admin/kantor/polda')}}" id="viewPolda"><div><i class="fa fa-circle fa-3x"></i></div><div>Polda</div></a></li>
		<li><a href="{{url('admin/kantor/polres')}}" id="viewPolres"><div><i class="fa fa-circle fa-3x"></i></div><div>Polres</div></a></li>
		<li><a href="{{url('admin/kantor/polsek')}}" id="viewPolsek"><div><i class="fa fa-circle fa-3x"></i></div><div>Polsek</div></a></li>
	</ul>
</div>

<script type="text/javascript">
	$(document).ready(function () {
		// set Theme for sub menu
		$("#sub-menu").jqxMenu({
			theme: 'metro'
		});
	});
</script>