@extends('main.layout')

@section('content')
@include('policeoffice.submenu')

@yield('policelist')
@stop